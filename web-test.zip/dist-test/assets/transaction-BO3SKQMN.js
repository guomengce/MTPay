import{Z as n}from"./index-BheMxZQT.js";function e(t={}){return n.get("/web/getTransactionList",{params:t})}function r(t){return n.get("/web/getTransactionInfo",{params:t})}export{r as a,e as f};
