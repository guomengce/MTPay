function s(t,r="—"){return t==null||t===""?r:String(t).replace(/(^|[\s≈])([+-]?)(\d+)((?:\.\d+)?)(?=$|\s)/g,(f,e,n,c,o)=>e+n+c.replace(/\B(?=(\d{3})+(?!\d))/g,",")+o)}export{s as f};
